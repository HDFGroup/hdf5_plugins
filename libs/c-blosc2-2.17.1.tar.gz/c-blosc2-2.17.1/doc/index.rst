.. toctree::
   :hidden:

   C-Blosc2 <c-blosc2>
