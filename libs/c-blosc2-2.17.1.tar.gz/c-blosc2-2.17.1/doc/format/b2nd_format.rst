.. include:: ../../README_B2ND_FORMAT.rst
