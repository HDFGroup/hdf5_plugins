.. include:: defs.rst
.. _contributors:

Contributors
============

* LLNL |zfp| team

  - Peter Lindstrom
  - Markus Salasoo
  - Matt Larsen
  - Stephen Herbein
  - Mark Miller

* External contributors

  - Chuck Atkins, Kitware (CMake support)
  - Stephen Hamilton, Johns Hopkins University (VTK plugin)
  - Mark Kim, ORNL (original CUDA port)
  - Amik St-Cyr, Shell (OpenMP compressor)
  - Eric Suchyta, ORNL (ADIOS plugin)
