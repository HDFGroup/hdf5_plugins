#ifndef CFP_HEADER_H
#define CFP_HEADER_H

typedef struct {
  void* object;
} cfp_header;

#endif
