#include "zfp/bitstream.h"
#include "zfp/bitstream.inl"

const size_t stream_word_bits = wsize;
