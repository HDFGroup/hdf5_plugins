#define FL_PT_DATA
#define SCALAR_BITS 32
#define ZFP_TYPE zfp_type_float
