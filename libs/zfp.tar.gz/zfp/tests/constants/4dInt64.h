#include "universalConsts.h"
#include "int64Consts.h"

#define DIM_INT_STR 4dInt64
