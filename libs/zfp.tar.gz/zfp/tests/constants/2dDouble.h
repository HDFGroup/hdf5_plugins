#include "universalConsts.h"
#include "doubleConsts.h"

#define DIM_INT_STR 2dDouble
