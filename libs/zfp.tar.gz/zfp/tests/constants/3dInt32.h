#include "universalConsts.h"
#include "int32Consts.h"

#define DIM_INT_STR 3dInt32
