#define SCALAR_BITS 64
#define ZFP_TYPE zfp_type_int64
