#include "array/zfparray1.h"
using namespace zfp;

#define ARRAY_DIMS_SCALAR_TEST Array1fTest
#define ARRAY_DIMS_SCALAR_TEST_ITERS Array1fTestIters

#include "utils/gtest1fTest.h"

#include "testArrayItersBase.cpp"
#include "testArray1ItersBase.cpp"
