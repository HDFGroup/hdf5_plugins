#include "array/zfparray3.h"
using namespace zfp;

#define ARRAY_DIMS_SCALAR_TEST Array3fTest
#define ARRAY_DIMS_SCALAR_TEST_ITERS Array3fTestIters

#include "utils/gtest3fTest.h"

#include "testArrayItersBase.cpp"
#include "testArray3ItersBase.cpp"
