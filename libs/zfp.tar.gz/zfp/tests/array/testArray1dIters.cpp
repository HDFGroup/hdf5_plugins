#include "array/zfparray1.h"
using namespace zfp;

#define ARRAY_DIMS_SCALAR_TEST Array1dTest
#define ARRAY_DIMS_SCALAR_TEST_ITERS Array1dTestIters

#include "utils/gtest1dTest.h"

#include "testArrayItersBase.cpp"
#include "testArray1ItersBase.cpp"
