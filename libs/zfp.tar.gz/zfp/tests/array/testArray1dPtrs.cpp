#include "array/zfparray1.h"
using namespace zfp;

#define ARRAY_DIMS_SCALAR_TEST Array1dTest
#define ARRAY_DIMS_SCALAR_TEST_PTRS Array1dTestPtrs

#include "utils/gtest1dTest.h"

#include "testArrayPtrsBase.cpp"
