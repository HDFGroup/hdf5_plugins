#include "array/zfparray2.h"
using namespace zfp;

#define ARRAY_DIMS_SCALAR_TEST Array2fTest
#define ARRAY_DIMS_SCALAR_TEST_PTRS Array2fTestPtrs

#include "utils/gtest2fTest.h"

#include "testArrayPtrsBase.cpp"
#include "testArray2PtrsBase.cpp"
