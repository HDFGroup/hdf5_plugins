#define SIMPLE_TEST(x) int main(){ x; return 0; }

#ifdef STDC_HEADERS
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <float.h>
int main() { return 0; }
#endif /* STDC_HEADERS */


#ifdef HAVE_DEFAULT_SOURCE
/* check default source */
#include <features.h>

int
main(void)
{
#ifdef __GLIBC_PREREQ
  return __GLIBC_PREREQ(2,19);
#else
  return 0;
#endif /* defined(__GLIBC_PREREQ) */
}
#endif

#ifdef TEST_LFS_WORKS
/* Return 0 when LFS is available and 1 otherwise.  */
#define _LARGEFILE_SOURCE
#define _LARGEFILE64_SOURCE
#define _LARGE_FILES
#define _FILE_OFFSET_BITS 64
#include <sys/types.h>
#include <sys/stat.h>
#include <assert.h>
#include <stdio.h>

int main(int argc, char **argv)
{
  /* check that off_t can hold 2^63 - 1 and perform basic operations... */
#define OFF_T_64 (((off_t) 1 << 62) - 1 + ((off_t) 1 << 62))
  if (OFF_T_64 % 2147483647 != 1)
    return 1;

  /* stat breaks on SCO OpenServer */
  struct stat buf;
  stat( argv[0], &buf );
  if (!S_ISREG(buf.st_mode))
    return 2;

  FILE *file = fopen( argv[0], "r" );
  off_t offset = ftello( file );
  fseek( file, offset, SEEK_CUR );
  fclose( file );
  return 0;
}
#endif

#ifdef GETTIMEOFDAY_GIVES_TZ
#include <time.h>
#ifdef HAVE_SYS_TIME_H
#include <sys/time.h>
#endif
int main(void)
{
 struct timeval tv;
 struct timezone tz;
 tz.tz_minuteswest = 7777;  /* Initialize to an unreasonable number */
 tz.tz_dsttime = 7;
 gettimeofday(&tv, &tz);
    /* Check whether the function returned any value at all */
 if(tz.tz_minuteswest == 7777 && tz.tz_dsttime == 7)
     return 1;
 else return 0;
}
#endif

#ifdef LONE_COLON
int main(int argc, char * argv)
{
  return 0;
}
#endif

#ifdef CXX_HAVE_OFFSETOF

#include <stdio.h>
#include <stddef.h>

#ifdef FC_DUMMY_MAIN
#ifndef FC_DUMMY_MAIN_EQ_F77
#  ifdef __cplusplus
extern "C"
#  endif
int FC_DUMMY_MAIN()
{ return 1;}
#endif
#endif
int
main ()
{

  struct index_st
  {
    unsigned char type;
    unsigned char num;
    unsigned int len;
  };
  typedef struct index_st index_t;
  int x,y;
  x = offsetof(struct index_st, len);
  y = offsetof(index_t, num)

  ;
  return 0;
}

#endif

#ifdef HAVE_IOEO

#include <windows.h>
typedef void (WINAPI *PGNSI)(LPSYSTEM_INFO);
int main ()
{
	PGNSI pGNSI;
	pGNSI = (PGNSI) GetProcAddress(
      GetModuleHandle(TEXT("kernel32.dll")),
      "InitOnceExecuteOnce");
	if(NULL == pGNSI)
		return 1;
	else
		return 0;
}

#endif /* HAVE_IOEO */

#ifdef HAVE_STRUCT_VIDEOCONFIG

SIMPLE_TEST(struct videoconfig w; w.numtextcols=0);

#endif /* HAVE_TM_GMTOFF */

#ifdef HAVE_STRUCT_TEXT_INFO

SIMPLE_TEST(struct text_info w; w.screenwidth=0);

#endif /* HAVE_TM_GMTOFF */


#if defined( INLINE_TEST_inline ) || defined( INLINE_TEST___inline__ ) || defined( INLINE_TEST___inline )
#ifndef __cplusplus
typedef int foo_t;
static INLINE_TEST_INLINE foo_t static_foo () { return 0; }
INLINE_TEST_INLINE foo_t foo () {return 0; }
int main() { return 0; }
#endif

#endif /* INLINE_TEST */
