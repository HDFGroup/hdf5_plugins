export CONDA_HOME=$PREFIX
$PYTHON setup.py install     # Python command to install the script
