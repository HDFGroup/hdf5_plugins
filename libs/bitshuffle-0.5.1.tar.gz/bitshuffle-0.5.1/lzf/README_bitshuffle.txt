The LZF filter for HDF5 is part of the h5py project (http://h5py.alfven.org).
The version included with bitshuffle is from version 2.3 of h5py with no
modifications other than the addition of this README.
