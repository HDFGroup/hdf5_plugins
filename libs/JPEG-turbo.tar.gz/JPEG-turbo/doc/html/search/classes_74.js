var searchData=
[
  ['tjregion',['tjregion',['../structtjregion.html',1,'']]],
  ['tjscalingfactor',['tjscalingfactor',['../structtjscalingfactor.html',1,'']]],
  ['tjtransform',['tjtransform',['../structtjtransform.html',1,'']]]
];
