#include "zfp/array4.hpp"
using namespace zfp;

#define ARRAY_DIMS_SCALAR_TEST Array4dTest
#define ARRAY_DIMS_SCALAR_TEST_PTRS Array4dTestPtrs

#include "utils/gtest4dTest.h"

#include "testArrayPtrsBase.cpp"
#include "testArray4PtrsBase.cpp"
