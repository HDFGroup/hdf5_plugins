#include "zfp/array2.hpp"
using namespace zfp;

#define ARRAY_DIMS_SCALAR_TEST Array2dTest
#define ARRAY_DIMS_SCALAR_TEST_PTRS Array2dTestPtrs

#include "utils/gtest2dTest.h"

#include "testArrayPtrsBase.cpp"
#include "testArray2PtrsBase.cpp"
