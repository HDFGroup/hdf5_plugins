#include "zfp/array3.hpp"
using namespace zfp;

#define ARRAY_DIMS_SCALAR_TEST Array3fTest
#define ARRAY_DIMS_SCALAR_TEST_PTRS Array3fTestPtrs

#include "utils/gtest3fTest.h"

#include "testArrayPtrsBase.cpp"
#include "testArray3PtrsBase.cpp"
