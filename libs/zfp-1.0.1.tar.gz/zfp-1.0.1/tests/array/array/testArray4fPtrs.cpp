#include "zfp/array4.hpp"
using namespace zfp;

#define ARRAY_DIMS_SCALAR_TEST Array4fTest
#define ARRAY_DIMS_SCALAR_TEST_PTRS Array4fTestPtrs

#include "utils/gtest4fTest.h"

#include "testArrayPtrsBase.cpp"
#include "testArray4PtrsBase.cpp"
