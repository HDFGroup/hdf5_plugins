#include "zfp/array3.hpp"
using namespace zfp;

#define ARRAY_DIMS_SCALAR_TEST Array3dTest
#define ARRAY_DIMS_SCALAR_TEST_PTRS Array3dTestPtrs

#include "utils/gtest3dTest.h"

#include "testArrayPtrsBase.cpp"
#include "testArray3PtrsBase.cpp"
