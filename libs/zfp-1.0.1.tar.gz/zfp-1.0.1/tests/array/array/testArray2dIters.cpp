#include "zfp/array2.hpp"
using namespace zfp;

#define ARRAY_DIMS_SCALAR_TEST Array2dTest
#define ARRAY_DIMS_SCALAR_TEST_ITERS Array2dTestIters

#include "utils/gtest2dTest.h"

#include "testArrayItersBase.cpp"
#include "testArray2ItersBase.cpp"
