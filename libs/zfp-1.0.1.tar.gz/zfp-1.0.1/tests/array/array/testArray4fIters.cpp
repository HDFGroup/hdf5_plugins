#include "zfp/array4.hpp"
using namespace zfp;

#define ARRAY_DIMS_SCALAR_TEST Array4fTest
#define ARRAY_DIMS_SCALAR_TEST_ITERS Array4fTestIters

#include "utils/gtest4fTest.h"

#include "testArrayItersBase.cpp"
#include "testArray4ItersBase.cpp"
