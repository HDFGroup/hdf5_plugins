#define FL_PT_DATA
#define SCALAR_BITS 64
#define ZFP_TYPE zfp_type_double
