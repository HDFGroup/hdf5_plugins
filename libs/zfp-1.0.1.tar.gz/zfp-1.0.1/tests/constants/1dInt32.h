#include "universalConsts.h"
#include "int32Consts.h"

#define DIM_INT_STR 1dInt32
