#include "universalConsts.h"
#include "floatConsts.h"

#define DIM_INT_STR 4dFloat
