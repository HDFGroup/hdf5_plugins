.. |times| unicode:: 0x00d7
.. |minus| unicode:: 0x2212
.. |leq| unicode:: 0x2264
.. |geq| unicode:: 0x2265
.. |approx| unicode:: 0x2248
.. |sqrt| unicode:: 0x221a
.. |check| unicode:: 0x2713
.. |reg| unicode:: 0x00ae
.. |tm| unicode:: 0x2122
.. |zfp| replace:: zfp
.. |cfp| replace:: cfp
.. |zforp| replace:: zFORp
.. |zfpy| replace:: zfPy
.. |libzfp| replace:: :file:`libzfp`
.. |libcfp| replace:: :file:`libcfp`
.. |libzforp| replace:: :file:`libzFORp`
.. |zfpcmd| replace:: :program:`zfp`
.. |testzfp| replace:: :program:`testzfp`
.. |4powd| replace:: 4\ :sup:`d`
.. |4by4| replace:: 4 |times| 4
.. |4by4by4| replace:: 4 |times| 4 |times| 4
.. |4by4by4by4| replace:: 4 |times| 4 |times| 4 |times| 4
.. |proxyrelease| replace:: 0.5.2
.. |omprelease| replace:: 0.5.3
.. |dcrelease| replace:: 0.5.3
.. |4drelease| replace:: 0.5.4
.. |viewsrelease| replace:: 0.5.4
.. |cudarelease| replace:: 0.5.4
.. |cfprelease| replace:: 0.5.4
.. |revrelease| replace:: 0.5.5
.. |zforprelease| replace:: 0.5.5
.. |zfpyrelease| replace:: 0.5.5
.. |csizerelease| replace:: 0.5.5
.. |crpirelease| replace:: 1.0.0
.. |raiterrelease| replace:: 1.0.0
.. |64bitrelease| replace:: 1.0.0
.. |boolrelease| replace:: 1.0.0
.. |4darrrelease| replace:: 1.0.0
.. |fieldrelease| replace:: 1.0.0
.. |carrrelease| replace:: 1.0.0
.. |cpprelease| replace:: 1.0.0
.. |verrelease| replace:: 1.0.0
