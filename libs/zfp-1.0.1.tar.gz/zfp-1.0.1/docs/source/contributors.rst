.. include:: defs.rst
.. _contributors:

Contributors
============

* |zfp| development team

  - Peter Lindstrom
  - Danielle Asher

* Major contributors

  - Chuck Atkins
  - Stephen Herbein
  - Mark Kim
  - Matt Larsen
  - Mark Miller
  - Markus Salasoo
  - David Wade
  - Haiying Xu

For a full list of contributors, see the
`GitHub Contributors <https://github.com/LLNL/zfp/graphs/contributors>`__ page.
