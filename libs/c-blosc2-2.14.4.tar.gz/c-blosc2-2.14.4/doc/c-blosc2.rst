.. include:: ../README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   API Reference <reference/index>
   Format <format/index>
   Development <development/index>
